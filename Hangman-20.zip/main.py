import time, random

GunManDict = [
  "🥏        😀",
  " 🥏       😀",
  "  🥏      😀",
  "   🥏     😀",
  "    🥏    😀",
  "     🥏   🤔",
  "      🥏  😨",
  "       🥏 😱",
  "         💥🤕   - FAILED",
  "      🥏🛡️ 😌   - SAVED",
]

AlphabetString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
DisplayString = "--------------------------"
Alphabet_To_Display_String = dict(zip(AlphabetString, DisplayString))
#Word = "DOG"
#Word = WordList[random.randint(0, )]

IncorrectGuesses = []
BadAttempts = []
CorrectAttempts = []

WordList = open("Word.txt", "r")
WordDraft = (WordList.readlines()[random.randint(1,213)])
Word = (WordDraft.rstrip("\n")).upper()
WordList.close()

#print(Word)

DisplayedWord = "".join([Alphabet_To_Display_String[letter] for letter in Word.upper()])
DisplayedWord_List = list(DisplayedWord)

print("Welcome to Hangman!")
print()
time.sleep(1.5)
print("Please wait for the program to load...")
print()
time.sleep(1.5)
print("You have a " + str(len(Word)) + " letter word!")
print()

def GuessRound():
  print(" ".join(DisplayedWord_List))
  print()

  UserGuess = input("Enter a guess letter: ")
  print()

  if UserGuess.upper() in Word:
    print("Correct Guess!!!")
    print()
  else:
    print("Incorrect Guess...")
    print()

    IncorrectGuesses.append(UserGuess)
    BadAttempts.append("L")
    print(GunManDict[len(BadAttempts)])
    print()

  for i in range(len(Word)):
    if Word[i] == UserGuess.upper():
      del DisplayedWord_List[i]
      DisplayedWord_List.insert(i, UserGuess.upper())
      CorrectAttempts.append("W")
      #print(" ".join(DisplayedWord_List))

  print(" ".join(DisplayedWord_List))
  print()
  print("Incorrect Guesses: " + str(IncorrectGuesses))
  print()

#BadAttemptsValue = len(BadAttempts)
#CorrectAttemptsValue = len(CorrectAttempts)

while len(BadAttempts) < 8 or len(CorrectAttempts) < len(Word):
  print()
  GuessRound()
  print()

  if len(BadAttempts) == 8:
    print("YOU LOSE! The correct answer was " + Word)
    print()
    time.sleep(0.5)
    print()
    break

  if len(CorrectAttempts) == len(Word):
    print("YOU WIN!")
    print()
    time.sleep(0.5)
    print(GunManDict[9])
    print()
    print()
    break
    